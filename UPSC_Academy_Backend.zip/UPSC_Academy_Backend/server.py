"""UPSC Academy: single-server FastAPI + SQLite content publishing backend."""
import base64
import hmac
import os
import re
import secrets
import sqlite3
import uuid
from contextlib import contextmanager
from pathlib import Path

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent
DB = Path(os.environ.get('UPSC_DB_PATH', str(BASE / 'academy.sqlite3')))
UPLOADS = Path(os.environ.get('UPSC_UPLOAD_DIR', str(BASE / 'uploads')))
UPLOADS.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD = 15 * 1024 * 1024
ALLOWED = {'.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp'}
SUBJECTS = {'current-affairs','current-affairs-practice','history','geography','polity','economy','science-technology'}
SUBCATEGORIES = {
    'history': {'ancient','medieval','modern'},
    'geography': {'physical','indian','world'},
    'science-technology': {'physics','chemistry','biology','environment','technology'},
}

app = FastAPI(title='UPSC Academy API', docs_url=None, redoc_url=None)

@contextmanager
def db_conn():
    conn = sqlite3.connect(DB, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    DB.parent.mkdir(parents=True, exist_ok=True)
    with db_conn() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS lessons (
            path TEXT PRIMARY KEY,
            title TEXT NOT NULL DEFAULT '',
            body TEXT NOT NULL DEFAULT '',
            published INTEGER NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS attachments (
            id TEXT PRIMARY KEY,
            path TEXT NOT NULL,
            filename TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            mime TEXT NOT NULL,
            FOREIGN KEY(path) REFERENCES lessons(path)
        );
        CREATE INDEX IF NOT EXISTS attachment_path_idx ON attachments(path);
        ''')
init_db()


def validate_path(path: str):
    """Same routing model as the student website; no arbitrary writes."""
    items = path.strip('/').split('/')
    if len(items) < 4 or len(items) > 6 or items[0] not in SUBJECTS or items[1] not in ('hi','en'):
        raise HTTPException(422, 'Invalid content path')
    subject, lang, *rest = items
    if subject == 'current-affairs':
        good = len(rest)==2 and rest[0] in ('2025','2026') and rest[1] in [f'{i:02d}' for i in range(1,13)]
    elif subject == 'current-affairs-practice':
        good = len(rest)==3 and rest[0] in ('mcq','oneliners') and rest[1] in ('2025','2026') and rest[2] in [f'{i:02d}' for i in range(1,13)]
    elif subject in SUBCATEGORIES:
        good = len(rest)==3 and rest[0] in SUBCATEGORIES[subject] and rest[1] in ('mcq','oneliners') and rest[2] in [str(i) for i in range(1,11)]
    else:
        good = len(rest)==2 and rest[0] in ('mcq','oneliners') and rest[1] in [str(i) for i in range(1,11)]
    if not good:
        raise HTTPException(422,'Invalid subject/category/chapter/month combination')
    return '/'.join(items)


def require_admin(authorization: str | None):
    expected = os.environ.get('UPSC_ADMIN_PASSWORD','')
    if not expected:
        raise HTTPException(503, 'Set UPSC_ADMIN_PASSWORD on the server before editing content')
    if not authorization or not authorization.startswith('Basic '):
        raise HTTPException(401, 'Admin authorization required', headers={'WWW-Authenticate':'Basic realm="UPSC Admin"'})
    try:
        username, password = base64.b64decode(authorization[6:], validate=True).decode().split(':',1)
    except (ValueError, UnicodeDecodeError):
        raise HTTPException(401,'Invalid credentials')
    if not (hmac.compare_digest(username, 'admin') and hmac.compare_digest(password, expected)):
        raise HTTPException(401,'Invalid admin username or password')

class Lesson(BaseModel):
    path: str
    title: str = Field(default='', max_length=200)
    body: str = Field(default='', max_length=250000)
    published: bool = False

def attachment_rows(db, path):
    return [dict(r) for r in db.execute('SELECT id,filename,mime FROM attachments WHERE path=? ORDER BY filename',(path,))]

@app.get('/api/health')
def health():
    return {'status':'ok'}

@app.get('/api/content')
def public_content(path: str):
    path=validate_path(path)
    with db_conn() as db:
        row=db.execute('SELECT title,body,updated_at FROM lessons WHERE path=? AND published=1',(path,)).fetchone()
        if not row:
            return {'exists':False,'title':'','body':'','attachments':[]}
        return {'exists':True, **dict(row),'attachments':attachment_rows(db,path)}

@app.get('/api/admin/content')
def get_admin_content(path: str, authorization: str | None = Header(default=None)):
    require_admin(authorization)
    path=validate_path(path)
    with db_conn() as db:
        row=db.execute('SELECT title,body,published,updated_at FROM lessons WHERE path=?',(path,)).fetchone()
        if not row:
            return {'exists':False,'title':'','body':'','published':False,'attachments':[]}
        return {'exists':True,**dict(row),'published':bool(row['published']),'attachments':attachment_rows(db,path)}

@app.put('/api/admin/content')
def save_content(lesson:Lesson, authorization: str | None = Header(default=None)):
    require_admin(authorization)
    path=validate_path(lesson.path)
    with db_conn() as db:
        db.execute('''INSERT INTO lessons(path,title,body,published) VALUES (?,?,?,?)
            ON CONFLICT(path) DO UPDATE SET title=excluded.title,body=excluded.body,
            published=excluded.published,updated_at=CURRENT_TIMESTAMP''',
            (path,lesson.title.strip(),lesson.body,int(lesson.published)))
    return {'ok':True,'path':path}

@app.post('/api/admin/upload')
async def upload(path:str=Form(...), file:UploadFile=File(...), authorization: str | None = Header(default=None)):
    require_admin(authorization)
    path=validate_path(path)
    filename=Path(file.filename or 'document').name[:150]
    ext=Path(filename).suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(415,'Only PDF, PNG, JPG and WEBP files are allowed')
    data=await file.read(MAX_UPLOAD+1)
    if len(data)>MAX_UPLOAD:
        raise HTTPException(413,'File exceeds 15 MB limit')
    # Check the magic header, not just the extension supplied by the browser.
    magic_ok={'.pdf':data.startswith(b'%PDF-'),'.png':data.startswith(b'\x89PNG\r\n\x1a\n'),'.jpg':data.startswith(b'\xff\xd8\xff'),'.jpeg':data.startswith(b'\xff\xd8\xff'),'.webp':data.startswith(b'RIFF') and data[8:12]==b'WEBP'}
    if not magic_ok[ext]:
        raise HTTPException(415,'File content does not match its extension')
    fileid=uuid.uuid4().hex
    stored=fileid+ext
    dest=UPLOADS/stored
    try:
        dest.write_bytes(data)
        with db_conn() as db:
            db.execute('INSERT OR IGNORE INTO lessons(path) VALUES (?)',(path,))
            db.execute('INSERT INTO attachments(id,path,filename,stored_name,mime) VALUES (?,?,?,?,?)',(fileid,path,filename,stored,ALLOWED[ext]))
    except Exception:
        dest.unlink(missing_ok=True)
        raise
    return {'ok':True,'id':fileid,'filename':filename}

@app.delete('/api/admin/attachment/{fileid}')
def delete_attachment(fileid:str, authorization:str | None=Header(default=None)):
    require_admin(authorization)
    if not re.fullmatch('[0-9a-f]{32}',fileid):
        raise HTTPException(404,'Not found')
    with db_conn() as db:
        row=db.execute('SELECT stored_name FROM attachments WHERE id=?',(fileid,)).fetchone()
        if not row: raise HTTPException(404,'Not found')
        db.execute('DELETE FROM attachments WHERE id=?',(fileid,))
    (UPLOADS/row['stored_name']).unlink(missing_ok=True)
    return {'ok':True}

@app.get('/api/file/{fileid}')
def get_file(fileid:str):
    if not re.fullmatch('[0-9a-f]{32}',fileid):
        raise HTTPException(404,'Not found')
    with db_conn() as db:
        row=db.execute('''SELECT a.stored_name,a.filename,a.mime FROM attachments a JOIN lessons l ON l.path=a.path WHERE a.id=? AND l.published=1''',(fileid,)).fetchone()
    if not row: raise HTTPException(404,'Not found')
    filepath=UPLOADS/row['stored_name']
    if not filepath.is_file(): raise HTTPException(404,'File missing')
    return FileResponse(filepath, media_type=row['mime'], filename=row['filename'], content_disposition_type='attachment',headers={'X-Content-Type-Options':'nosniff'})

@app.get('/admin')
def admin():
    return FileResponse(BASE/'static'/'admin.html',headers={'Cache-Control':'no-store'})

@app.get('/')
def homepage():
    return FileResponse(BASE/'static'/'index.html')

app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')
