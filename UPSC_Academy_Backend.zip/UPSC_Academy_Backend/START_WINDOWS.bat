@echo off
cd /d "%~dp0"
if not exist .venv (python -m venv .venv)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if "%UPSC_ADMIN_PASSWORD%"=="" (
  echo Enter a strong new administrator password for this session:
  set /p UPSC_ADMIN_PASSWORD=Password: 
)
python -m uvicorn server:app --host 127.0.0.1 --port 8000
pause
