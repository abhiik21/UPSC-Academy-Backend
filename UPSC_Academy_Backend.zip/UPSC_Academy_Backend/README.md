# UPSC Academy — Admin Backend

This package contains your **7-subject student website**, an **administrator dashboard**, a **FastAPI backend**, an **SQLite content database**, and **PDF/image uploads**.

## Start on Windows

1. Install Python 3.11+ from python.org (check **Add Python to PATH**).
2. Extract the ZIP and open the `UPSC_Academy_Backend` folder.
3. Double-click `START_WINDOWS.bat`. It installs the required packages and starts the server. Enter a **strong admin password** when prompted (for that server session).
4. In Chrome, open **http://127.0.0.1:8000/** for students and **http://127.0.0.1:8000/admin** to upload material.
5. Admin login: username is `admin` (handled automatically); enter the server password in the admin dashboard.
6. Pick subject → language → category if relevant → MCQs/One-liners if relevant → chapter or year/month. Click **Load selected content** before editing; add text, choose **Publish for students**, save, then attach PDFs/images if needed.

**Do not double-click `static/index.html` to use this version:** the site must be opened through the running backend URL to load shared content.

## Linux/macOS alternative

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export UPSC_ADMIN_PASSWORD='put-a-long-secret-password-here'
uvicorn server:app --host 127.0.0.1 --port 8000
```

## Content structure

- Current Affairs: language → 2025/2026 → 12 months
- Current Affairs MCQ/One-liners: language → type → 2025/2026 → 12 months
- History: language → Ancient/Medieval/Modern → type → 10 chapters
- Geography: language → Physical/Indian/World → type → 10 chapters
- Polity and Economy: language → type → 10 chapters
- Science & Technology: language → Physics/Chemistry/Biology/Environment/Technology → type → 10 chapters

Each location has its own saved material; Hindi and English are independent. **Content is visible to students only when published**. The admin dashboard is not linked from the student website.

## Storage and backups

- `academy.sqlite3` is created automatically when first launched.
- Uploaded files are saved in `uploads/`.
- Back up both `academy.sqlite3` and `uploads/` frequently, ideally while the server is stopped.
- You can change their locations using `UPSC_DB_PATH` and `UPSC_UPLOAD_DIR` environment variables.

## Security and deployment notes

- All edit/upload/delete API endpoints require the configured admin password.
- The admin dashboard keeps the password only in the open browser tab; logging in again is required after a page refresh.
- PDF/image uploads are limited to 15 MB each and verified by file signature.
- This is a **single-administrator MVP**, not a production-hardened public hosting configuration. For public deployment use a proper HTTPS reverse proxy, a managed process, backups, rate limiting, stronger session-based admin authentication, and add admin audit logging before allowing collaborators.
- Password passed via HTTP Basic Auth must **never** be used over unencrypted public HTTP.
- The student website does not yet have student accounts or payments. MCQs are currently uploaded as formatted text or attachments, not auto-graded quizzes.
